module.exports = function(io, streams) {

	var mSockets = [];
	var ids = [];

	io.on('connection', function(client) {
		console.log('-- ' + client.id + ' joined --');
		
		mSockets.push(client);
		for (var i in mSockets) {
			ids[i] = mSockets[i].id;
		}
		client.emit('id', ids);

		// client.emit('id', client.id);

		client.on('message', function(details) {
			var otherClient = io.sockets.connected[details.to];

			console.log("details=" + JSON.stringify(details));

			if (!otherClient) {
				return;
			}
			delete details.to;
			details.from = client.id;
			otherClient.emit('message', details);
		});

		client.on('readyToStream', function(options) {
			console.log('-- ' + client.id + ' is ready to stream --');
			console.log("options.name=" + options.name);
			streams.addStream(client.id, options.name);
		});

		client.on('update', function(options) {
			streams.update(client.id, options.name);
		});

		function leave() {
			console.log('-- ' + client.id + ' left --');
			streams.removeStream(client.id);
		}

		client.on('disconnect', leave);
		client.on('leave', leave);
	});
};
